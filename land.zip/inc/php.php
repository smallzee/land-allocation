<?php
	session_start();

	//Database variables
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "";
	$db_name = "project_land";

	$connect = mysql_connect($db_host,$db_user,$db_pass) or die(mysql_error());
	$db = mysql_select_db($db_name,$connect) or die(mysql_error());
	require 'func.php';
?>