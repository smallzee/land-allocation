</div>
</div>
</div>
<p style='padding: 10px; text-align: center;'>
	Project Supervised by Mr. A.U Adewale
</p>
</div>
</div>
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<script type="text/javascript" src="lib/bootstrap/js/bootstrap.min.js"></script>
<script src="js/main.js"></script>