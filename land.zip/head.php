<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo @$page_title;?></title>
	<!--css-->
	<!-- Bootstrap core CSS -->
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="IE=Edge"/> 		
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />		
	<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.min.css">	
	<link rel="stylesheet" type="text/css" href="lib/font-awesome/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>
<body>